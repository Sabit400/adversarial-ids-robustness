"""
Synthetic Network Intrusion Dataset Generator
-----------------------------------------------
Generates a labeled tabular dataset with NSL-KDD-style connection features
(duration, byte counts, protocol/service/flag categories, error rates, and
host-based traffic statistics) for a binary intrusion-detection task
(Normal vs. Attack).

This dataset is SYNTHETIC. Real NSL-KDD / CIC-IDS style datasets require
external download access not available in this project's development
environment. The generator reproduces the statistical shape and feature
semantics documented in intrusion-detection literature so the adversarial
robustness pipeline (baseline model -> attack -> defense -> re-evaluation)
can be built and evaluated end-to-end honestly.

Author: Sabit Md Asad (project pipeline authored with Claude)
"""

import numpy as np
import pandas as pd

RANDOM_SEED = 42
N_SAMPLES = 30000
ATTACK_RATIO = 0.35  # NSL-KDD has a substantial attack proportion, unlike DNS traffic

NUMERIC_FEATURES_FOR_NOISE = [
    "duration", "src_bytes", "dst_bytes", "count", "serror_rate",
    "same_srv_rate", "diff_srv_rate",
]

PROTOCOLS = ["tcp", "udp", "icmp"]
SERVICES = ["http", "ftp", "smtp", "dns", "telnet", "private", "other"]
FLAGS = ["SF", "S0", "REJ", "RSTO", "RSTR"]


def generate_dataset(n_samples: int = N_SAMPLES, seed: int = RANDOM_SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    is_attack = rng.random(n_samples) < ATTACK_RATIO
    label = np.where(is_attack, "Attack", "Normal")

    n = n_samples
    df = pd.DataFrame({"label": label})

    # --- Duration: attacks often very short (scans/floods) or very long (slow exfil) ---
    duration = np.zeros(n)
    duration[~is_attack] = rng.exponential(30, (~is_attack).sum())
    duration[is_attack] = rng.choice(
        [rng.exponential(1, is_attack.sum()).mean(), rng.exponential(200, is_attack.sum()).mean()]
    ) * rng.exponential(1, is_attack.sum())
    df["duration"] = np.clip(duration, 0, 3000)

    # --- Source/destination byte counts ---
    src_bytes = np.zeros(n)
    src_bytes[~is_attack] = rng.gamma(3, 400, (~is_attack).sum())
    src_bytes[is_attack] = rng.gamma(1.5, 150, is_attack.sum())  # often smaller payloads (probes)
    df["src_bytes"] = np.clip(src_bytes, 0, 50000)

    dst_bytes = np.zeros(n)
    dst_bytes[~is_attack] = rng.gamma(3, 600, (~is_attack).sum())
    dst_bytes[is_attack] = rng.gamma(1.2, 80, is_attack.sum())  # attacks get little response back
    df["dst_bytes"] = np.clip(dst_bytes, 0, 50000)

    # --- Connection counts to same host in last window ---
    count = np.zeros(n, dtype=int)
    count[~is_attack] = rng.poisson(5, (~is_attack).sum())
    count[is_attack] = rng.poisson(45, is_attack.sum())  # scan/flood pattern
    df["count"] = count

    # --- Serror rate (SYN error rate) ---
    serror_rate = np.zeros(n)
    serror_rate[~is_attack] = rng.beta(1, 30, (~is_attack).sum())
    serror_rate[is_attack] = rng.beta(4, 6, is_attack.sum())
    df["serror_rate"] = np.clip(serror_rate, 0, 1)

    # --- Same srv rate (fraction of connections to same service) ---
    same_srv_rate = np.zeros(n)
    same_srv_rate[~is_attack] = rng.beta(8, 2, (~is_attack).sum())
    same_srv_rate[is_attack] = rng.beta(2, 5, is_attack.sum())
    df["same_srv_rate"] = np.clip(same_srv_rate, 0, 1)

    # --- Diff srv rate ---
    diff_srv_rate = np.zeros(n)
    diff_srv_rate[~is_attack] = rng.beta(1, 10, (~is_attack).sum())
    diff_srv_rate[is_attack] = rng.beta(3, 5, is_attack.sum())
    df["diff_srv_rate"] = np.clip(diff_srv_rate, 0, 1)

    # --- Wrong fragment count ---
    wrong_fragment = np.zeros(n, dtype=int)
    wrong_fragment[is_attack] = rng.poisson(0.3, is_attack.sum())
    df["wrong_fragment"] = wrong_fragment

    # --- Number of failed login attempts ---
    num_failed_logins = np.zeros(n, dtype=int)
    num_failed_logins[~is_attack] = rng.poisson(0.02, (~is_attack).sum())
    num_failed_logins[is_attack] = rng.poisson(0.8, is_attack.sum())
    df["num_failed_logins"] = num_failed_logins

    # --- Categorical: protocol, service, flag ---
    protocol_probs = {"Normal": [0.55, 0.35, 0.10], "Attack": [0.45, 0.30, 0.25]}
    df["protocol_type"] = [
        rng.choice(PROTOCOLS, p=protocol_probs[lbl]) for lbl in df.label
    ]
    service_probs_normal = [0.30, 0.10, 0.10, 0.15, 0.05, 0.20, 0.10]
    service_probs_attack = [0.15, 0.10, 0.08, 0.10, 0.15, 0.32, 0.10]
    df["service"] = [
        rng.choice(SERVICES, p=service_probs_normal if lbl == "Normal" else service_probs_attack)
        for lbl in df.label
    ]
    flag_probs_normal = [0.75, 0.05, 0.05, 0.05, 0.10]
    flag_probs_attack = [0.30, 0.30, 0.20, 0.10, 0.10]
    df["flag"] = [
        rng.choice(FLAGS, p=flag_probs_normal if lbl == "Normal" else flag_probs_attack)
        for lbl in df.label
    ]

    # Add label noise and feature-level overlap so the classes are not
    # trivially separable. This mirrors real intrusion-detection data,
    # where a meaningful fraction of connections are genuinely ambiguous,
    # and is also necessary so that adversarial perturbations have a
    # measurable effect on a baseline model that hasn't simply memorized
    # a clean linear boundary.
    flip_mask = rng.random(n) < 0.06
    df.loc[flip_mask, "label"] = np.where(df.loc[flip_mask, "label"] == "Normal", "Attack", "Normal")

    for col in NUMERIC_FEATURES_FOR_NOISE:
        noise = rng.normal(0, df[col].std() * 0.35, n)
        df[col] = np.clip(df[col] + noise, 0, None)

    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = generate_dataset()
    out_path = "/home/claude/adversarial-ids-robustness/data/intrusion_traffic.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df["label"].value_counts(normalize=True))
