"""
FastAPI prototype: submit a network connection record, and see side-by-side
predictions from BOTH the baseline (undefended) and hardened (adversarially
trained) models, both on the clean input and under a live FGSM/PGD attack
at a chosen epsilon. This makes the value of adversarial training directly
visible on a single request.

Run with:
    uvicorn app:app --reload --port 8001
"""

import sys
import json
import joblib
import torch
import pandas as pd
from pathlib import Path
from fastapi import FastAPI
from pydantic import BaseModel, Field

sys.path.append(str(Path(__file__).parent.parent / "src"))
from model import IDSClassifier
from attacks import fgsm_attack, pgd_attack

RESULTS_DIR = Path(__file__).parent.parent / "results"

app = FastAPI(
    title="Adversarial IDS Robustness Comparison API",
    description="Compares baseline vs. adversarially-trained IDS models under FGSM/PGD attack.",
    version="1.0.0",
)

scaler = joblib.load(RESULTS_DIR / "scaler.joblib")
label_encoder = joblib.load(RESULTS_DIR / "label_encoder.joblib")
with open(RESULTS_DIR / "feature_cols.json") as f:
    FEATURE_COLS = json.load(f)

NUMERIC_FEATURES = [
    "duration", "src_bytes", "dst_bytes", "count", "serror_rate",
    "same_srv_rate", "diff_srv_rate", "wrong_fragment", "num_failed_logins",
]

baseline_model = IDSClassifier(input_dim=len(FEATURE_COLS))
baseline_model.load_state_dict(torch.load(RESULTS_DIR / "baseline_model.pt", weights_only=True))
baseline_model.eval()

hardened_model = IDSClassifier(input_dim=len(FEATURE_COLS))
hardened_model.load_state_dict(torch.load(RESULTS_DIR / "hardened_model.pt", weights_only=True))
hardened_model.eval()


class ConnectionRecord(BaseModel):
    duration: float
    src_bytes: float
    dst_bytes: float
    count: int
    serror_rate: float = Field(..., ge=0, le=1)
    same_srv_rate: float = Field(..., ge=0, le=1)
    diff_srv_rate: float = Field(..., ge=0, le=1)
    wrong_fragment: int
    num_failed_logins: int
    protocol_type: str
    service: str
    flag: str
    attack_epsilon: float = Field(0.1, description="Perturbation budget for the live attack demo")


def _to_scaled_tensor(record: dict) -> torch.Tensor:
    df = pd.DataFrame([record])
    df_encoded = pd.get_dummies(df, columns=["protocol_type", "service", "flag"])
    for col in FEATURE_COLS:
        if col not in df_encoded.columns:
            df_encoded[col] = 0
    df_encoded = df_encoded[FEATURE_COLS].astype(float)
    scaled = scaler.transform(df_encoded)
    return torch.tensor(scaled, dtype=torch.float32)


def _predict(model, X: torch.Tensor) -> dict:
    with torch.no_grad():
        logits = model(X)
        probs = torch.softmax(logits, dim=1)[0]
    pred_idx = int(probs.argmax())
    return {
        "predicted_class": label_encoder.classes_[pred_idx],
        "probabilities": {
            cls: round(float(p), 4) for cls, p in zip(label_encoder.classes_, probs)
        },
    }


@app.get("/")
def root():
    return {
        "service": "Adversarial IDS Robustness Comparison API",
        "classes": list(label_encoder.classes_),
        "docs": "/docs",
    }


@app.post("/compare")
def compare(record: ConnectionRecord):
    row = record.model_dump()
    epsilon = row.pop("attack_epsilon")
    X = _to_scaled_tensor(row)

    # Pseudo-label for attack generation: use the baseline model's own clean
    # prediction as the attack target label (untargeted attack maximizing
    # loss relative to the model's current belief), which is standard practice
    # when the true label is not assumed known at inference time.
    with torch.no_grad():
        baseline_pseudo_label = baseline_model(X).argmax(dim=1)
        hardened_pseudo_label = hardened_model(X).argmax(dim=1)

    X_adv_vs_baseline = pgd_attack(baseline_model, X, baseline_pseudo_label, epsilon=epsilon)
    X_adv_vs_hardened = pgd_attack(hardened_model, X, hardened_pseudo_label, epsilon=epsilon)

    return {
        "epsilon": epsilon,
        "baseline_model": {
            "clean_prediction": _predict(baseline_model, X),
            "under_pgd_attack": _predict(baseline_model, X_adv_vs_baseline),
        },
        "hardened_model": {
            "clean_prediction": _predict(hardened_model, X),
            "under_pgd_attack": _predict(hardened_model, X_adv_vs_hardened),
        },
    }


@app.get("/health")
def health():
    return {"status": "ok"}
