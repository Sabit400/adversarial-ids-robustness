"""
Evaluate a model's accuracy under FGSM and PGD attacks across a range of
perturbation budgets (epsilon). Produces a robustness curve and metrics
summary. Used both for the baseline model (attack.py) and, after adversarial
training, for the hardened model (compare_models.py).
"""

import sys
import json
import torch
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from model import IDSClassifier
from attacks import fgsm_attack, pgd_attack

RESULTS_DIR = Path("/home/claude/adversarial-ids-robustness/results")
EPSILONS = [0.0, 0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.3]


def clean_accuracy(model, X, y):
    model.eval()
    with torch.no_grad():
        preds = model(X).argmax(dim=1)
    return (preds == y).float().mean().item()


def attack_accuracy(model, X, y, epsilon, attack_type="fgsm"):
    if epsilon == 0.0:
        return clean_accuracy(model, X, y)
    if attack_type == "fgsm":
        X_adv = fgsm_attack(model, X, y, epsilon)
    elif attack_type == "pgd":
        X_adv = pgd_attack(model, X, y, epsilon)
    else:
        raise ValueError(attack_type)
    model.eval()
    with torch.no_grad():
        preds = model(X_adv).argmax(dim=1)
    return (preds == y).float().mean().item()


def run_robustness_sweep(model_path: str, label: str, out_prefix: str):
    test_data = torch.load(RESULTS_DIR / "test_tensors.pt", weights_only=False)
    X_test, y_test = test_data["X_test"], test_data["y_test"]

    model = IDSClassifier(input_dim=X_test.shape[1])
    model.load_state_dict(torch.load(model_path, weights_only=True))
    model.eval()

    results = {"epsilon": EPSILONS, "fgsm_accuracy": [], "pgd_accuracy": []}

    for eps in EPSILONS:
        fgsm_acc = attack_accuracy(model, X_test, y_test, eps, "fgsm")
        pgd_acc = attack_accuracy(model, X_test, y_test, eps, "pgd")
        results["fgsm_accuracy"].append(fgsm_acc)
        results["pgd_accuracy"].append(pgd_acc)
        print(f"[{label}] eps={eps:.2f} | FGSM acc={fgsm_acc:.4f} | PGD acc={pgd_acc:.4f}")

    with open(RESULTS_DIR / f"{out_prefix}_robustness.json", "w") as f:
        json.dump(results, f, indent=2)

    plt.figure(figsize=(7, 5))
    plt.plot(EPSILONS, results["fgsm_accuracy"], marker="o", label="FGSM")
    plt.plot(EPSILONS, results["pgd_accuracy"], marker="s", label="PGD (10 steps)")
    plt.xlabel("Perturbation budget (epsilon, L-infinity)")
    plt.ylabel("Classification accuracy")
    plt.title(f"Robustness under attack — {label}")
    plt.ylim(0, 1.05)
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(RESULTS_DIR / f"{out_prefix}_robustness_curve.png", dpi=150)
    plt.close()
    print(f"Saved {out_prefix}_robustness_curve.png")

    return results


if __name__ == "__main__":
    run_robustness_sweep(
        model_path=str(RESULTS_DIR / "baseline_model.pt"),
        label="Baseline (undefended) model",
        out_prefix="baseline",
    )
