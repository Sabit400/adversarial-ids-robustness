"""
Train the baseline (non-adversarially-trained) IDS classifier.
This model is the one we will attack with FGSM/PGD in evaluate_attacks.py,
and later compare against an adversarially-trained hardened version.
"""

import sys
import json
import joblib
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from preprocessing import load_and_preprocess
from model import IDSClassifier

DATA_PATH = "/home/claude/adversarial-ids-robustness/data/intrusion_traffic.csv"
RESULTS_DIR = Path("/home/claude/adversarial-ids-robustness/results")
RESULTS_DIR.mkdir(exist_ok=True)

torch.manual_seed(42)
np.random.seed(42)


def train_baseline(epochs: int = 30, lr: float = 1e-3, batch_size: int = 128):
    data = load_and_preprocess(DATA_PATH)
    X_train = torch.tensor(data["X_train"])
    y_train = torch.tensor(data["y_train"])
    X_test = torch.tensor(data["X_test"])
    y_test = torch.tensor(data["y_test"])

    model = IDSClassifier(input_dim=X_train.shape[1])
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    n_train = X_train.shape[0]
    history = {"train_loss": [], "train_acc": [], "test_acc": []}

    for epoch in range(epochs):
        model.train()
        perm = torch.randperm(n_train)
        epoch_loss, correct = 0.0, 0
        for i in range(0, n_train, batch_size):
            idx = perm[i : i + batch_size]
            xb, yb = X_train[idx], y_train[idx]

            optimizer.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item() * xb.size(0)
            correct += (logits.argmax(dim=1) == yb).sum().item()

        train_loss = epoch_loss / n_train
        train_acc = correct / n_train

        model.eval()
        with torch.no_grad():
            test_logits = model(X_test)
            test_acc = (test_logits.argmax(dim=1) == y_test).float().mean().item()

        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        history["test_acc"].append(test_acc)

        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch {epoch+1:2d}/{epochs} | loss={train_loss:.4f} | train_acc={train_acc:.4f} | test_acc={test_acc:.4f}")

    torch.save(model.state_dict(), RESULTS_DIR / "baseline_model.pt")
    joblib.dump(data["scaler"], RESULTS_DIR / "scaler.joblib")
    joblib.dump(data["label_encoder"], RESULTS_DIR / "label_encoder.joblib")
    with open(RESULTS_DIR / "feature_cols.json", "w") as f:
        json.dump(data["feature_cols"], f)
    with open(RESULTS_DIR / "baseline_history.json", "w") as f:
        json.dump(history, f, indent=2)

    # Save test set as tensors for the attack/evaluation scripts
    torch.save({"X_test": X_test, "y_test": y_test}, RESULTS_DIR / "test_tensors.pt")

    print(f"\nFinal baseline test accuracy: {history['test_acc'][-1]:.4f}")
    print("Saved model, scaler, encoders, and test tensors to:", RESULTS_DIR)
    return model, data


if __name__ == "__main__":
    train_baseline()
