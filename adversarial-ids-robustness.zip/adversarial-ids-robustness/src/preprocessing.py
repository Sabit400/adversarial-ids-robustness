"""
Preprocessing pipeline for the Adversarial IDS Robustness project.
Numeric features are scaled to [0, 1] (important for FGSM/PGD epsilon to be
meaningful and comparable across features); categoricals are one-hot encoded.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder

NUMERIC_FEATURES = [
    "duration", "src_bytes", "dst_bytes", "count", "serror_rate",
    "same_srv_rate", "diff_srv_rate", "wrong_fragment", "num_failed_logins",
]
CATEGORICAL_FEATURES = ["protocol_type", "service", "flag"]
TARGET = "label"


def load_and_preprocess(csv_path: str, test_size: float = 0.3, random_state: int = 42):
    df = pd.read_csv(csv_path)

    df_encoded = pd.get_dummies(df, columns=CATEGORICAL_FEATURES, drop_first=True)
    feature_cols = [c for c in df_encoded.columns if c != TARGET]

    X = df_encoded[feature_cols].astype(float)
    le = LabelEncoder()
    y = le.fit_transform(df_encoded[TARGET])  # Normal=0/Attack=1 (or vice versa, deterministic)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # MinMax scale ALL features (numeric + one-hot, harmless) to [0, 1]
    # This is important so that perturbation budgets (epsilon) are comparable
    # across features when generating adversarial examples.
    scaler = MinMaxScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    return {
        "X_train": X_train_scaled.astype(np.float32),
        "y_train": y_train.astype(np.int64),
        "X_test": X_test_scaled.astype(np.float32),
        "y_test": y_test.astype(np.int64),
        "feature_cols": feature_cols,
        "scaler": scaler,
        "label_encoder": le,
    }


if __name__ == "__main__":
    result = load_and_preprocess("/home/claude/adversarial-ids-robustness/data/intrusion_traffic.csv")
    print("Train shape:", result["X_train"].shape)
    print("Test shape:", result["X_test"].shape)
    print("Classes:", result["label_encoder"].classes_)
    print("Feature range check -> min:", result["X_train"].min(), "max:", result["X_train"].max())
