"""
Compare baseline (undefended) vs. adversarially-trained (hardened) model
robustness on the same epsilon sweep, and produce a summary table.
"""

import json
import matplotlib.pyplot as plt
from pathlib import Path

RESULTS_DIR = Path("/home/claude/adversarial-ids-robustness/results")

with open(RESULTS_DIR / "baseline_robustness.json") as f:
    baseline = json.load(f)
with open(RESULTS_DIR / "hardened_robustness.json") as f:
    hardened = json.load(f)

eps = baseline["epsilon"]

fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)

axes[0].plot(eps, baseline["fgsm_accuracy"], marker="o", label="Baseline", color="#D85A30")
axes[0].plot(eps, hardened["fgsm_accuracy"], marker="o", label="Adversarially trained", color="#1D9E75")
axes[0].set_title("FGSM attack")
axes[0].set_xlabel("Perturbation budget (epsilon)")
axes[0].set_ylabel("Classification accuracy")
axes[0].set_ylim(0, 1.05)
axes[0].grid(alpha=0.3)
axes[0].legend()

axes[1].plot(eps, baseline["pgd_accuracy"], marker="s", label="Baseline", color="#D85A30")
axes[1].plot(eps, hardened["pgd_accuracy"], marker="s", label="Adversarially trained", color="#1D9E75")
axes[1].set_title("PGD attack (10 steps)")
axes[1].set_xlabel("Perturbation budget (epsilon)")
axes[1].set_ylim(0, 1.05)
axes[1].grid(alpha=0.3)
axes[1].legend()

fig.suptitle("Robustness comparison: baseline vs. adversarially-trained model")
plt.tight_layout()
plt.savefig(RESULTS_DIR / "comparison_robustness.png", dpi=150)
plt.close()
print("Saved comparison_robustness.png")

# Summary table at key epsilon values
summary_rows = []
for i, e in enumerate(eps):
    summary_rows.append({
        "epsilon": e,
        "baseline_fgsm": round(baseline["fgsm_accuracy"][i], 4),
        "hardened_fgsm": round(hardened["fgsm_accuracy"][i], 4),
        "baseline_pgd": round(baseline["pgd_accuracy"][i], 4),
        "hardened_pgd": round(hardened["pgd_accuracy"][i], 4),
        "pgd_improvement": round(hardened["pgd_accuracy"][i] - baseline["pgd_accuracy"][i], 4),
    })

with open(RESULTS_DIR / "comparison_summary.json", "w") as f:
    json.dump(summary_rows, f, indent=2)

print("\nEpsilon | Baseline PGD | Hardened PGD | Improvement")
for row in summary_rows:
    print(f"{row['epsilon']:.2f}    | {row['baseline_pgd']:.4f}       | {row['hardened_pgd']:.4f}       | +{row['pgd_improvement']:.4f}")
