"""
Baseline feed-forward neural network for intrusion detection.
Simple architecture (3 hidden layers) chosen deliberately: adversarial
robustness experiments are about the training procedure and attack/defense
dynamics, not about squeezing out extra accuracy from a deeper network.
"""

import torch
import torch.nn as nn


class IDSClassifier(nn.Module):
    def __init__(self, input_dim: int, hidden_dims=(64, 32, 16), num_classes: int = 2):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(prev_dim, h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(0.2))
            prev_dim = h
        layers.append(nn.Linear(prev_dim, num_classes))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)
