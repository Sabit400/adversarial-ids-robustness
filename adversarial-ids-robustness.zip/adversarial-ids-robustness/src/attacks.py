"""
Adversarial attack implementations: FGSM and PGD (L-infinity norm).

Implemented directly with PyTorch autograd (rather than via a library) so
the mechanics are transparent and explainable end-to-end.

Note on domain validity: perturbed samples are clipped to [0, 1] (the
MinMax-scaled feature range) after perturbation, so every adversarial
example remains within the same normalized bounds as legitimate traffic
features. This is a standard simplification for tabular adversarial ML
research; it does not guarantee the perturbed values correspond to a
physically realizable network connection (e.g., a fractional byte count),
which is a known limitation discussed in the README.
"""

import torch
import torch.nn as nn


def fgsm_attack(model: nn.Module, X: torch.Tensor, y: torch.Tensor, epsilon: float) -> torch.Tensor:
    """
    Fast Gradient Sign Method (Goodfellow et al., 2015).
    Single-step perturbation in the direction that maximizes loss.
    """
    model.eval()
    X_adv = X.clone().detach().requires_grad_(True)

    logits = model(X_adv)
    loss = nn.functional.cross_entropy(logits, y)
    loss.backward()

    perturbation = epsilon * X_adv.grad.sign()
    X_adv = (X_adv + perturbation).clamp(0, 1).detach()
    return X_adv


def pgd_attack(
    model: nn.Module,
    X: torch.Tensor,
    y: torch.Tensor,
    epsilon: float,
    alpha: float = None,
    num_steps: int = 10,
) -> torch.Tensor:
    """
    Projected Gradient Descent (Madry et al., 2018).
    Iterative multi-step FGSM with projection back into the epsilon-ball
    around the original input after each step. Widely regarded as a
    stronger attack than single-step FGSM.
    """
    if alpha is None:
        alpha = epsilon / 4  # standard heuristic: ~num_steps/2.5 fits within budget

    model.eval()
    X_orig = X.clone().detach()
    X_adv = X.clone().detach()

    for _ in range(num_steps):
        X_adv.requires_grad_(True)
        logits = model(X_adv)
        loss = nn.functional.cross_entropy(logits, y)
        grad = torch.autograd.grad(loss, X_adv)[0]

        X_adv = X_adv.detach() + alpha * grad.sign()
        # Project back into the epsilon-ball (L-infinity) around the original input
        perturbation = torch.clamp(X_adv - X_orig, -epsilon, epsilon)
        X_adv = (X_orig + perturbation).clamp(0, 1).detach()

    return X_adv
