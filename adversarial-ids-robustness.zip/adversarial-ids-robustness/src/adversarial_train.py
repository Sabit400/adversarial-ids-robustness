"""
Adversarial training (Madry et al., 2018 style defense).

At each training step, replace clean batches with PGD-perturbed versions
(generated on-the-fly against the current model weights) before computing
the loss and updating parameters. This trains the model's decision boundary
to be robust within the epsilon-ball used during training, at some cost to
clean accuracy (the well-documented robustness/accuracy trade-off).
"""

import sys
import json
import torch
import torch.nn as nn
import numpy as np
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from preprocessing import load_and_preprocess
from model import IDSClassifier
from attacks import pgd_attack

DATA_PATH = "/home/claude/adversarial-ids-robustness/data/intrusion_traffic.csv"
RESULTS_DIR = Path("/home/claude/adversarial-ids-robustness/results")

TRAIN_EPSILON = 0.1  # train-time robustness budget
TRAIN_PGD_STEPS = 7

torch.manual_seed(42)
np.random.seed(42)


def adversarial_train(epochs: int = 30, lr: float = 1e-3, batch_size: int = 128):
    data = load_and_preprocess(DATA_PATH)
    X_train = torch.tensor(data["X_train"])
    y_train = torch.tensor(data["y_train"])
    X_test = torch.tensor(data["X_test"])
    y_test = torch.tensor(data["y_test"])

    model = IDSClassifier(input_dim=X_train.shape[1])
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()

    n_train = X_train.shape[0]
    history = {"train_loss": [], "train_acc_adv": [], "test_acc_clean": []}

    for epoch in range(epochs):
        model.train()
        perm = torch.randperm(n_train)
        epoch_loss, correct = 0.0, 0

        for i in range(0, n_train, batch_size):
            idx = perm[i : i + batch_size]
            xb, yb = X_train[idx], y_train[idx]

            # Generate adversarial examples against the CURRENT model weights
            X_adv = pgd_attack(model, xb, yb, epsilon=TRAIN_EPSILON, num_steps=TRAIN_PGD_STEPS)

            model.train()
            optimizer.zero_grad()
            logits = model(X_adv)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item() * xb.size(0)
            correct += (logits.argmax(dim=1) == yb).sum().item()

        train_loss = epoch_loss / n_train
        train_acc_adv = correct / n_train

        model.eval()
        with torch.no_grad():
            test_acc_clean = (model(X_test).argmax(dim=1) == y_test).float().mean().item()

        history["train_loss"].append(train_loss)
        history["train_acc_adv"].append(train_acc_adv)
        history["test_acc_clean"].append(test_acc_clean)

        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(
                f"Epoch {epoch+1:2d}/{epochs} | adv_loss={train_loss:.4f} | "
                f"adv_train_acc={train_acc_adv:.4f} | clean_test_acc={test_acc_clean:.4f}"
            )

    torch.save(model.state_dict(), RESULTS_DIR / "hardened_model.pt")
    with open(RESULTS_DIR / "hardened_history.json", "w") as f:
        json.dump(history, f, indent=2)

    print(f"\nFinal hardened model clean test accuracy: {history['test_acc_clean'][-1]:.4f}")
    print("Saved hardened model to:", RESULTS_DIR / "hardened_model.pt")
    return model


if __name__ == "__main__":
    adversarial_train()
